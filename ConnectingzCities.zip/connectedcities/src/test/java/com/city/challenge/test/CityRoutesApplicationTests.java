package com.city.challenge.test;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.util.HashMap;

import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.util.ResourceUtils;

@RunWith(SpringRunner.class)
@SpringBootTest
public class CityRoutesApplicationTests {


@Test
public void checkFirstSet() throws IOException {
   String expectedData = "Boston,NewYork";
        
   File file = ResourceUtils.getFile("classpath:resources/cities.txt");

	String fileContent = new String(Files.readAllBytes(file.toPath()));
 
	String data = new String(fileContent);
 
    Assert.assertEquals(expectedData, data.trim());
}

}
