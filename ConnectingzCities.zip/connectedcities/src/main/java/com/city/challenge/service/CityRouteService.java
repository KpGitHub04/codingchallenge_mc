package com.city.challenge.service;

import java.io.FileNotFoundException;
import java.io.IOException;

import org.springframework.context.annotation.Configuration;

@Configuration
public interface CityRouteService {

	
	public String isCityConnected(String origin,String destination) throws FileNotFoundException, IOException;
	
}
