package com.city.challenge.constants;

public interface CityRouteConstants {

	String isConnectedTrue="true";
	String isConnectedFalse="false";
}
