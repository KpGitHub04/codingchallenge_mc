package com.city.challenge;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CityRoutesApplication {

	public static void main(String[] args) {
		SpringApplication.run(CityRoutesApplication.class, args);
	}
}
