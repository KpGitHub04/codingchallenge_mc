package com.city.challenge.serviceimpl;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.util.HashMap;
import java.util.Map;

import org.springframework.stereotype.Component;
import org.springframework.util.ResourceUtils;

import com.city.challenge.constants.CityRouteConstants;
import com.city.challenge.service.CityRouteService;

@Component
public class CityRouteServiceImpl implements CityRouteService {
	

	public String isCityConnected(String origin,String destination) throws IOException {
	
	File file = ResourceUtils.getFile("classpath:static/cities.txt");

	String isConnected="";
	HashMap<String,String> cityMap = new HashMap<String,String>();
	String fileContent = new String(Files.readAllBytes(file.toPath()));
	String finalString = fileContent.replaceAll("\\r\\n", ",");
	String cityArray[] = finalString.split(",");
	
	cityMap =  convertStringToMap(cityArray);
	for(Map.Entry<String,String> entry:cityMap.entrySet()) {
		
		if(origin.equalsIgnoreCase(entry.getKey()) &&
				destination.equalsIgnoreCase(entry.getValue()))
		{
			isConnected=CityRouteConstants.isConnectedTrue;
		}else {
			isConnected=CityRouteConstants.isConnectedFalse;
		}
	
	}
	return isConnected;
}

public HashMap<String,String> convertStringToMap(String[] content){
	HashMap<String,String>  convertedMap = new HashMap<String,String>();
	for(int i=0;i<content.length-1;i+=2) {
		convertedMap.put(content[i],content[i+1]);
	}
	return convertedMap;
}
}
