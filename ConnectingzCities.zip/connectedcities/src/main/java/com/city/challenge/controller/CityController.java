package com.city.challenge.controller;

import java.io.FileNotFoundException;
import java.io.IOException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.city.challenge.model.CityRouteResponse;
import com.city.challenge.service.CityRouteService;

@RestController
public class CityController {


@Autowired
private CityRouteService cityRouteService;
		
@RequestMapping(value="/conectedcities" ,method=RequestMethod.GET)
public CityRouteResponse isCitiesConnected(@RequestParam(value="origin", required=true) String origin, 
@RequestParam( value="destination", required=true) String destination) throws FileNotFoundException, IOException {

	CityRouteResponse cityRouteResponse = new CityRouteResponse();
	String isConnected  = cityRouteService.isCityConnected(origin, destination);
	cityRouteResponse.setMessage(isConnected);

	return cityRouteResponse;

}

}
